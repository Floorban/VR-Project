﻿namespace Unity.XR.PXR
{
    public enum USBConfigModeEnum
    {
        MTP=0,
        CHARGE=1
    }
}