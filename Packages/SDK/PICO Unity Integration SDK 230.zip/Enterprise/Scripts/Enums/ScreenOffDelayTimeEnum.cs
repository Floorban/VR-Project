﻿namespace Unity.XR.PXR
{
    public enum ScreenOffDelayTimeEnum
    {
        THREE,
        TEN ,
        THIRTY ,
        SIXTY,
        THREE_HUNDRED,
        SIX_HUNDRED ,
        NEVER 
    }
}