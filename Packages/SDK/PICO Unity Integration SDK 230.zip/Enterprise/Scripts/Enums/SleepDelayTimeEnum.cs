﻿namespace Unity.XR.PXR
{
    public enum SleepDelayTimeEnum
    {
        FIFTEEN ,
        THIRTY ,
        SIXTY ,
        THREE_HUNDRED ,
        SIX_HUNDRED ,
        ONE_THOUSAND_AND_EIGHT_HUNDRED ,
        NEVER 
    }
}