package com.picoxr.tobservice.interfaces;

public interface LongCallback {
    void CallBack(long var1);
}
