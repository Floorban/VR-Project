package com.picoxr.tobservice.interfaces;

public interface IntCallback {
    void CallBack(int var1);
}
