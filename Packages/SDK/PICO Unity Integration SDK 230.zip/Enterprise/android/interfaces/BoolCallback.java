package com.picoxr.tobservice.interfaces;

public interface BoolCallback {
    void CallBack(Boolean var1);
}
